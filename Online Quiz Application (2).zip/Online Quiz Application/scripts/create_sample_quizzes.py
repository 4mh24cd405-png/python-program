import os
import sys
from pathlib import Path

# Ensure project root is on sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quiz_project.settings')
import django
django.setup()

from quizzes.models import Quiz, Question, Choice

sample_data = [
    {
        'title': 'Math Basics',
        'description': 'Simple arithmetic questions',
        'time_limit': 10,
        'questions': [
            {'text': 'What is 5 + 7?', 'choices': [('10', False), ('12', True), ('13', False)]},
            {'text': 'What is 9 - 4?', 'choices': [('5', True), ('6', False), ('7', False)]},
            {'text': 'What is 3 * 4?', 'choices': [('7', False), ('12', True), ('14', False)]},
        ]
    },
    {
        'title': 'General Knowledge',
        'description': 'Short GK quiz',
        'time_limit': 7,
        'questions': [
            {'text': 'What is the capital of France?', 'choices': [('Berlin', False), ('Madrid', False), ('Paris', True)]},
            {'text': 'Which planet is known as the Red Planet?', 'choices': [('Earth', False), ('Mars', True), ('Jupiter', False)]},
            {'text': 'How many continents are there?', 'choices': [('5', False), ('6', False), ('7', True)]},
        ]
    },
    {
        'title': 'Science Basics',
        'description': 'Basic science questions',
        'time_limit': 8,
        'questions': [
            {'text': 'Water boils at what temperature (C)?', 'choices': [('90', False), ('100', True), ('110', False)]},
            {'text': 'What gas do plants absorb?', 'choices': [('Oxygen', False), ('Carbon Dioxide', True), ('Nitrogen', False)]},
            {'text': 'What is H2O?', 'choices': [('Hydrogen', False), ('Oxygen', False), ('Water', True)]},
        ]
    }
]

created = 0
for quiz_data in sample_data:
    title = quiz_data['title']
    if Quiz.objects.filter(title=title).exists():
        print(f"Quiz '{title}' already exists, skipping.")
        continue
    q = Quiz.objects.create(title=title, description=quiz_data['description'], time_limit=quiz_data['time_limit'])
    for ques in quiz_data['questions']:
        que = Question.objects.create(quiz=q, text=ques['text'])
        for choice_text, is_correct in ques['choices']:
            Choice.objects.create(question=que, text=choice_text, is_correct=is_correct)
    print(f"Created quiz '{title}' (id={q.id})")
    created += 1

print(f"Finished. Created {created} new quizzes.")
