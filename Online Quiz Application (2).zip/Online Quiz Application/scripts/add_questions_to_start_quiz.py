import os
import sys
from pathlib import Path

# Ensure project root is on sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quiz_project.settings')
import django
django.setup()

from quizzes.models import Quiz, Question, Choice

quiz_title = 'Start Quiz'
quiz = Quiz.objects.filter(title=quiz_title).first()
if not quiz:
    print(f"Quiz '{quiz_title}' not found. Create the quiz first.")
    sys.exit(1)

questions = [
    ("What is the capital of India?", [('Mumbai', False), ('New Delhi', True), ('Kolkata', False), ('Chennai', False)]),
    ("How many colours are there in a rainbow?", [('Five', False), ('Six', False), ('Seven', True), ('Eight', False)]),
    ("Which planet is known as the Red Planet?", [('Mercury', False), ('Venus', False), ('Mars', True), ('Jupiter', False)]),
    ("Who was the first Prime Minister of India?", [('Mahatma Gandhi', False), ('Jawaharlal Nehru', True), ('Sardar Vallabhbhai Patel', False), ('Indira Gandhi', False)]),
    ("Which is the largest mammal on Earth?", [('Elephant', False), ('Blue Whale', True), ('Giraffe', False), ('Orca', False)]),
]

added = 0
for text, choices in questions:
    if Question.objects.filter(quiz=quiz, text=text).exists():
        print(f"Question already exists: {text}")
        continue
    que = Question.objects.create(quiz=quiz, text=text)
    for choice_text, is_correct in choices:
        Choice.objects.create(question=que, text=choice_text, is_correct=is_correct)
    print(f"Added question: {text}")
    added += 1

print(f"Finished. Added {added} questions to '{quiz_title}'.")
