import os
import sys
from pathlib import Path

# Ensure project root is on sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quiz_project.settings')
import django
django.setup()

from quizzes.models import Quiz, Question, Choice

quiz_title = 'Start Quiz'
if Quiz.objects.filter(title=quiz_title).exists():
    print(f"Quiz '{quiz_title}' already exists, skipping.")
else:
    q = Quiz.objects.create(title=quiz_title, description='10-question starter quiz with 4 options each', time_limit=15)
    questions = [
        ("What is the capital of India?", [('Mumbai', False), ('New Delhi', True), ('Kolkata', False), ('Chennai', False)]),
        ("Which number is prime?", [('4', False), ('6', False), ('13', True), ('9', False)]),
        ("What is 7 + 8?", [('14', False), ('15', True), ('16', False), ('13', False)]),
        ("Which planet is known as the Red Planet?", [('Venus', False), ('Mars', True), ('Jupiter', False), ('Saturn', False)]),
        ("What is H2O commonly known as?", [('Hydrogen', False), ('Oxygen', False), ('Water', True), ('Helium', False)]),
        ("Which language is used to style web pages?", [('HTML', False), ('Python', False), ('CSS', True), ('SQL', False)]),
        ("Who wrote 'Romeo and Juliet'?", [('Charles Dickens', False), ('William Shakespeare', True), ('Mark Twain', False), ('Leo Tolstoy', False)]),
        ("What is the boiling point of water at sea level (°C)?", [('90', False), ('100', True), ('120', False), ('80', False)]),
        ("Which organ pumps blood through the body?", [('Lungs', False), ('Kidney', False), ('Heart', True), ('Liver', False)]),
        ("Which gas do plants absorb from the atmosphere?", [('Oxygen', False), ('Carbon Dioxide', True), ('Nitrogen', False), ('Hydrogen', False)]),
    ]
    for text, choices in questions:
        que = Question.objects.create(quiz=q, text=text)
        for choice_text, is_correct in choices:
            Choice.objects.create(question=que, text=choice_text, is_correct=is_correct)
    print(f"Created quiz '{quiz_title}' with {len(questions)} questions (id={q.id})")
