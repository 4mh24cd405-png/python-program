import os
import sys
from pathlib import Path

# Ensure project root is on sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'quiz_project.settings')
import django
django.setup()

from quizzes.models import Quiz, Question, Choice

sample_data = [
    {
        'title': 'Kannada Basics',
        'description': 'ಕನ್ನಡ ಮೂಲಾತ್ಮಕ ಪ್ರಶ್ನೆಗಳು',
        'time_limit': 10,
        'questions': [
            {'text': 'ಕನ್ನಡದ ರಾಜ್ಯಭಾಷೆ ಯಾವುದು?', 'choices': [('ಕನ್ನಡ', True), ('ತೆಲುಗು', False), ('ಹಿಂದಿ', False)]},
            {'text': 'ಕಾಳಿದಾಸನು ಯಾವ ಭಾಷೆಯಲ್ಲಿ ಕೃತಿ ಟೀಟಿದನು?', 'choices': [('ಕನ್ನಡ', False), ('ಸಂಸ್ಕೃತ', True), ('ತಮಿಳು', False)]},
            {'text': 'ಬೆಂಗಳೂರು ಯಾವ ರಾಜ್ಯದಲ್ಲಿದೆ?', 'choices': [('ಕೇರಳ', False), ('ಕರ್ನಾಟಕ', True), ('ತಮಿಳುನಾಡು', False)]},
        ]
    },
    {
        'title': 'Kannada Vocabulary',
        'description': 'ಪದಗಳ ಅರ್ಥಗಳನ್ನು ಪರೀಕ್ಷಿಸುವ ಪರೀಕ್ಷೆ',
        'time_limit': 7,
        'questions': [
            {'text': '"ಹನುಮ" ಎಂದರೆ?', 'choices': [('ಹಣ್ಣು', False), ('ಮಂಗ', False), ('ಹುಟ್ಟು', False)]},
            {'text': '"ನಮಸ್ಕಾರ" ಯಾವ ರೀತಿಯ ಶಬ್ದ?', 'choices': [('ಅಭಿವಾದನೆ', True), ('ಪ್ರಶ್ನೆ', False), ('ನಾಮ', False)]},
            {'text': '"ಗುರು" ಎಂಬ ಪದದ ಅರ್ಥ?', 'choices': [('ಶಿಕ್ಷಕ', True), ('ವಿದ್ಯಾರ್ಥಿ', False), ('ವೃತ್ತಿ', False)]},
        ]
    },
    {
        'title': 'Kannada Culture',
        'description': 'ಕನ್ನಡ ಸಂಸ್ಕೃತಿ ಸಂಬಂಧಿತ ಪ್ರಶ್ನೆಗಳು',
        'time_limit': 8,
        'questions': [
            {'text': 'ಯಕ್ಷಗಾನ ವಿಶೇಷತೆ ಯಾವುದು?', 'choices': [('ನವ್ಲಿ ನೃತ್ಯ', False), ('ವೇಷಭೂಷಣ ಮತ್ತು ನಾಟಕ', True), ('ಸಹಜ ಸಂಗೀತ', False)]},
            {'text': 'ಪುಣ್ಯಕ್ಷೇತ್ರ ಮಾಧ್ಯಮ ಯಾವುದು?', 'choices': [('ಹಬ್ಬ', False), ('ರಾಜಕೀಯ', False), ('ಅದ್ರವ್ಯ', False)]},
            {'text': 'ವೀರಶೈವರು ಮುಖ್ಯವಾಗಿ ಯಾವ ಭಾಗದಲ್ಲಿ ಪ್ರಕರಣವಾಗಿದ್ದಾರೆ?', 'choices': [('ಧಾರ್ಮಿಕ ಚಿಂತನೆಯಲ್ಲಿ', True), ('ಕ್ರೀಡೆ', False), ('ವಾಣಿಜ್ಯ', False)]},
        ]
    }
]

created = 0
for quiz_data in sample_data:
    title = quiz_data['title']
    if Quiz.objects.filter(title=title).exists():
        print(f"Quiz '{title}' already exists, skipping.")
        continue
    q = Quiz.objects.create(title=title, description=quiz_data['description'], time_limit=quiz_data['time_limit'])
    for ques in quiz_data['questions']:
        que = Question.objects.create(quiz=q, text=ques['text'])
        for choice_text, is_correct in ques['choices']:
            Choice.objects.create(question=que, text=choice_text, is_correct=is_correct)
    print(f"Created quiz '{title}' (id={q.id})")
    created += 1

print(f"Finished. Created {created} new Kannada quizzes.")
