from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from quizzes.models import Attempt

# Create your views here.

@login_required
def my_results(request):
    attempts = Attempt.objects.filter(user=request.user).order_by('-start_time')
    return render(request, 'results/list.html', {'attempts': attempts})
