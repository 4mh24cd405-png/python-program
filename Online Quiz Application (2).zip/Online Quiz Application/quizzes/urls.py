from django.urls import path
from . import views

urlpatterns = [
    path('', views.quiz_list, name='list'),
    path('<int:quiz_id>/', views.quiz_detail, name='detail'),
    path('<int:quiz_id>/start/', views.start_quiz, name='start'),
    path('<int:quiz_id>/take/<int:attempt_id>/', views.take_quiz, name='take'),
]
