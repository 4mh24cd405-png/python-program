from django.shortcuts import render, get_object_or_404, redirect
from .models import Quiz, Question, Choice, Attempt
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.http import HttpResponseForbidden

def quiz_list(request):
    quizzes = Quiz.objects.filter(active=True)
    return render(request, 'quizzes/list.html', {'quizzes': quizzes})


def quiz_detail(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id)
    return render(request, 'quizzes/detail.html', {'quiz': quiz})


@login_required
def start_quiz(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id)
    # create attempt
    attempt = Attempt.objects.create(user=request.user, quiz=quiz)
    return redirect('quizzes:take', quiz_id=quiz.id, attempt_id=attempt.id)


@login_required
def take_quiz(request, quiz_id, attempt_id):
    quiz = get_object_or_404(Quiz, id=quiz_id)
    attempt = get_object_or_404(Attempt, id=attempt_id, quiz=quiz, user=request.user)

    # prevent re-taking finished attempts
    if attempt.end_time:
        return HttpResponseForbidden('This attempt is already completed.')

    questions = quiz.questions.all()

    if request.method == 'POST':
        # grade: count correct answers as marks
        correct = 0
        total = questions.count()
        for q in questions:
            selected = request.POST.get(str(q.id))
            if selected:
                try:
                    choice = Choice.objects.get(id=int(selected), question=q)
                    if choice.is_correct:
                        correct += 1
                except Choice.DoesNotExist:
                    pass
        # store marks (integer) instead of percentage
        attempt.score = correct
        attempt.end_time = timezone.now()
        attempt.save()
        return redirect('results:my_results')

    return render(request, 'quizzes/take.html', {'quiz': quiz, 'attempt': attempt, 'questions': questions})
